<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\HeaderModel;
use App\Models\NoticeModel;
use App\Models\PagesModel;
use App\Models\CourseModel;
use App\Models\NewsModel;
use App\Models\BranchModel;
use App\Models\AdmissionModel;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
  
    public function home() 
    {
        $data['getNotice'] = NoticeModel::getRecordFront();
        return view('home.index', $data);
    }

    public function page($id)

    { $data['getRecord'] = PagesModel::getPage($id);
        return view('home.page', $data);
    }
    public function notice($id)
    { $data['getRecord'] = NoticeModel::getNotice($id);
        return view('home.notice', $data);
    }
    public function course($id)
    { $data['getRecord'] = CourseModel::getCourse($id);
        return view('home.course', $data);
    }
    public function news()
    {
        $data['getNews'] = NewsModel::getFrontNews();
        return view('home.news', $data);
    }
    public function newsdetails($id)
    {
        $data['getNews'] = NewsModel::getNews($id);
        return view('home.newsdetails', $data);
    }

    // public function result()
    // {
    //     $data['getRecord'] = NewsModel::getNews($id);
    //     return view('home.result', $data);
    // }
    public function branch($id)
    {   $data['getRecord'] = BranchModel::getBranch($id);
        return view('home.branch', $data);
    }
    // public function branchdetails() 
    // {
    //     return view('home.branchdetails');
    // }





    public function certificateverify()
    { $admissions = AdmissionModel::where("created_at",">", Carbon::now()->subMonths(3))
           
           ->orderBy('id', 'desc')->get();
        
        return view('home.certificateverify', compact('admissions'));
    }

    public function search(Request $request)
{
    $search = $request->search;
    $query = AdmissionModel::query();
    $query -> whereAny(['registrationNo','phone'], 'like', "%$search%");
    $admissions = $query->get();

    return view('home.search', $admissions);
}






    public function members()
    {
        return view('home.members');
    }
    public function jobholder()
    {
        return view('home.jobholder');
    }
    public function successstory()
    {
        return view('home.successstory');
    }
    public function contact()
    {
        return view('home.contact');
    }



}
